On trouvera ici 3 choses 

Un dossier documentation avec un ODD et une page HTMl
Un dossier sch�ma dans lequel se trouve mon sch�ma en Relax NG compact Syntax
Mon �dition XML, qui s'apelle description d'un pi�ce source.xml